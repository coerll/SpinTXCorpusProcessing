This folder is where you should save all of your original plain-text transcripts.
Make sure that the file names match up with those in MainInput.txt.